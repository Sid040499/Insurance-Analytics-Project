create table brokerage(id int auto_increment primary key, income_class varchar(100) not null, amount decimal(10,2));
desc brokerage;

create table fees(id int auto_increment primary key, income_class varchar(100) not null, amount decimal(10,2));

create table invoice(id int auto_increment primary key, income_class varchar(100) not null, amount decimal(10,2));

create table target_budget(id int auto_increment primary key, new_budget decimal(10,2), cross_sell decimal(10,2), renewal decimal(10,2));

----- Kpi ,invoice,fees,brokrage
SELECT income_class,sum(amount) FROM fees group by income_class;
SELECT income_class,sum(amount) FROM brokerage group by income_class;
SELECT income_class,sum(amount) FROM invoice group by income_class;

----- Target budget
select sum(new_budget) from target_budget;
select sum(cross_sell) from target_budget;
select sum(renewal) from target_budget;

----Achievement table...
create table achievement(income_class varchar(100), amount decimal(10,2));

-- insert into achievement values('Cross Sell', 'select sum(amount) from (fees+brokerage)');

insert into achievement values('Cross Sell', 
(SELECT round(SUM(amount), 2) AS 'cross sell'
FROM (
    SELECT amount as amount
    FROM fees
    WHERE income_class = 'Cross Sell'
    UNION ALL
    SELECT amount as amount
    FROM brokerage
    WHERE income_class = 'Cross Sell'
) AS combined_query)
);
select * from achievement;
insert into achievement values('new', 
(SELECT round(SUM(amount), 2) AS 'new'
FROM (
    SELECT amount as amount
    FROM fees
    WHERE income_class = 'new'
    UNION ALL
    SELECT amount as amount
    FROM brokerage
    WHERE income_class = 'new'
) AS combined_query)
);
insert into achievement values('renewal', 
(SELECT round(SUM(amount), 2) AS 'renewal'
FROM (
    SELECT amount as amount
    FROM fees
    WHERE income_class = 'renewal'
    UNION ALL
    SELECT amount as amount
    FROM brokerage
    WHERE income_class = 'renewal'
) AS combined_query)
);


---- Cross Sell placed Ach %
select 
concat(round((select amount from achievement where income_class= 'Cross Sell')/(select sum(cross_sell) from target_budget)*100,2), '%')  
AS "Cross Sell Placed Ach (%)" ;

---- cross sell invoice Ach%
select
concat(round((select sum(amount) from invoice where income_class='cross sell')/(select sum(cross_sell) from target_budget)*100,2),'%') as 
"Cross sell invoice Ach %";

----- New placed Ach %
select 
concat(round((select amount from achievement where income_class="new")/(select sum(new_budget) from target_budget)*100,2), '%')  
AS "New Placed Ach (%)" ;

---- New Invoice Ach %
select
concat(round((select sum(amount) from invoice where income_class='New')/(select sum(new_budget) from target_budget)*100,2),'%') as 
"New invoice Ach %";

----- Renewal Placed Ach %
select 
concat(round((select amount from achievement where income_class="Renewal")/(select sum(renewal) from target_budget)*100,2), '%')  
AS "New Placed Ach (%)" ;

---- Renewal Invoice Ach %
select 
concat(round((select sum(amount) from invoice where income_class= 'Renewal')/(select sum(renewal) from target_budget)*100,2), '%')  
AS "Renewal Invoice Ach %";

























